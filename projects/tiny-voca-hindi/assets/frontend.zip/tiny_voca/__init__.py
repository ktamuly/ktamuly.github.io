"""Hindi front end of tiny-voca only (no model code), for the browser."""
