"""Hindi text normalisation: digits, money, times, dates, percentages, units -> words.

The same function serves training-data preparation, the inference front end and the
ASR check, so they agree.
Readings follow everyday spoken Hindi: साढ़े/सवा/पौने/डेढ़/ढाई for halves and quarters,
lakh/crore grouping, years 1100-1999 as hundreds (उन्नीस सौ पचानवे).
"""
import re

ONES = ("शून्य एक दो तीन चार पाँच छह सात आठ नौ दस ग्यारह बारह तेरह चौदह पंद्रह सोलह सत्रह अठारह उन्नीस बीस "
        "इक्कीस बाईस तेईस चौबीस पच्चीस छब्बीस सत्ताईस अट्ठाईस उनतीस तीस इकतीस बत्तीस तैंतीस चौंतीस पैंतीस "
        "छत्तीस सैंतीस अड़तीस उनतालीस चालीस इकतालीस बयालीस तैंतालीस चवालीस पैंतालीस छियालीस सैंतालीस "
        "अड़तालीस उनचास पचास इक्यावन बावन तिरेपन चौवन पचपन छप्पन सत्तावन अट्ठावन उनसठ साठ इकसठ बासठ "
        "तिरसठ चौंसठ पैंसठ छियासठ सड़सठ अड़सठ उनहत्तर सत्तर इकहत्तर बहत्तर तिहत्तर चौहत्तर पचहत्तर छिहत्तर "
        "सतहत्तर अठहत्तर उन्यासी अस्सी इक्यासी बयासी तिरासी चौरासी पचासी छियासी सत्तासी अट्ठासी नवासी "
        "नब्बे इक्यानवे बानवे तिरानवे चौरानवे पचानवे छियानवे सत्तानवे अट्ठानवे निन्यानवे").split()
assert len(ONES) == 100
ORDINALS = {1: "पहला", 2: "दूसरा", 3: "तीसरा", 4: "चौथा", 6: "छठा"}
MONTHS = "जनवरी फ़रवरी मार्च अप्रैल मई जून जुलाई अगस्त सितंबर अक्टूबर नवंबर दिसंबर".split()
DEVA_DIGITS = str.maketrans("०१२३४५६७८९", "0123456789")

def cardinal(n):
    """Integer -> Hindi words, Indian grouping (हज़ार, लाख, करोड़, अरब)."""
    n = int(n)
    if n < 0:
        return "माइनस " + cardinal(-n)
    if n < 100:
        return ONES[n]
    parts = []
    for size, name in ((10**9, "अरब"), (10**7, "करोड़"), (10**5, "लाख"), (1000, "हज़ार"), (100, "सौ")):
        if n >= size:
            parts.append(f"{cardinal(n // size)} {name}")
            n %= size
    if n:
        parts.append(ONES[n])
    return " ".join(parts)

def year(n):
    n = int(n)
    if 1100 <= n <= 1999 and n % 100:
        return f"{ONES[n // 100]} सौ {ONES[n % 100]}"
    if 1100 <= n <= 1999:
        return f"{ONES[n // 100]} सौ"
    return cardinal(n)

def ordinal(n, gender="m"):
    n = int(n)
    word = ORDINALS.get(n) or (cardinal(n) + "वाँ")
    if gender == "f":
        word = word[:-1] + "ी" if word.endswith("ा") else word.replace("वाँ", "वीं")
    return word

def digits(s):
    return " ".join(ONES[int(c)] for c in s if c.isdigit())

def fraction_reading(whole, frac):
    """3.5 -> साढ़े तीन, 1.5 -> डेढ़, 2.5 -> ढाई; other decimals -> दशमलव + digits."""
    w = int(whole)
    if frac == "5" or frac == "50":
        return {0: "आधा", 1: "डेढ़", 2: "ढाई"}.get(w, f"साढ़े {cardinal(w)}")
    return f"{cardinal(w)} दशमलव {digits(frac)}"

def clock(h, m):
    h, m = int(h), int(m)
    nxt = 1 if h == 12 else h + 1
    if m == 0:
        return f"{cardinal(h)} बजे"
    if m == 30:
        return {1: "डेढ़ बजे", 2: "ढाई बजे"}.get(h, f"साढ़े {cardinal(h)} बजे")
    if m == 15:
        return f"सवा {cardinal(h)} बजे"
    if m == 45:
        return f"पौने {cardinal(nxt)} बजे"
    return f"{cardinal(h)} बजकर {cardinal(m)} मिनट"

UNITS = {"km": "किलोमीटर", "किमी": "किलोमीटर", "kg": "किलो", "किग्रा": "किलो", "g": "ग्राम", "mg": "मिलीग्राम",
         "m": "मीटर", "cm": "सेंटीमीटर", "mm": "मिलीमीटर", "l": "लीटर", "ml": "मिलीलीटर", "°c": "डिग्री सेल्सियस",
         "°": "डिग्री", "gb": "जीबी", "mb": "एमबी", "kmph": "किलोमीटर प्रति घंटा", "km/h": "किलोमीटर प्रति घंटा"}
NUM = r"\d[\d,]*(?:\.\d+)?"

def amount(s):
    """A number string with optional Indian/Western commas and decimals -> words."""
    s = s.replace(",", "")
    if "." in s:
        whole, frac = s.split(".", 1)
        return fraction_reading(whole or "0", frac)
    return cardinal(s)

def _money(m):
    whole, frac, scale = m.group(1), None, m.group(2)
    whole = whole.replace(",", "")
    if "." in whole:
        whole, frac = whole.split(".", 1)
    if scale:   # ₹1.5 लाख, ₹2 करोड़
        return f"{fraction_reading(whole, frac) if frac else cardinal(whole)} {scale} रुपये"
    words = f"{cardinal(whole)} रुपये"
    if frac and int(frac):
        words += f" {cardinal(int(frac.ljust(2, '0')[:2]))} पैसे"
    return words

RULES = [
    # phone numbers: 10 digits (optionally +91 / split 5+5) -> digit by digit, a pause in the middle
    (re.compile(r"(?:\+91[\s-]?)?(\d{5})[\s-]?(\d{5})\b"), lambda m: f"{digits(m.group(1))}, {digits(m.group(2))}"),
    # money
    (re.compile(rf"(?:₹|रु\.?|Rs\.?)\s?({NUM})(?:\s?(हज़ार|लाख|करोड़|अरब))?"), _money),
    (re.compile(rf"({NUM})\s?(?:रुपये|रुपए|रुपया)"), lambda m: f"{amount(m.group(1))} रुपये"),
    # clock times 4:30, 10:05 (optionally followed by बजे, which the reading already contains)
    (re.compile(r"\b(\d{1,2}):(\d{2})(?:\s?बजे)?"), lambda m: clock(m.group(1), m.group(2))),
    # dates: 15/08/2026, 15-08-2026
    (re.compile(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b"),
     lambda m: f"{cardinal(m.group(1))} {MONTHS[int(m.group(2)) - 1]} {year(m.group(3))}" if 1 <= int(m.group(2)) <= 12 else m.group(0)),
    # "15 अगस्त 2026", "अगस्त 2026", "सन 1995", years before "में"/"से"/"तक"/"का"/"की"
    (re.compile(r"\b(\d{1,2})\s(" + "|".join(MONTHS) + r")\s(\d{4})\b"), lambda m: f"{cardinal(m.group(1))} {m.group(2)} {year(m.group(3))}"),
    (re.compile(r"(" + "|".join(MONTHS) + r"|सन|साल|वर्ष)\s(\d{4})\b"), lambda m: f"{m.group(1)} {year(m.group(2))}"),
    (re.compile(r"\b(1[1-9]\d\d|20\d\d)\s(?=में|से|तक|का|की|के|को)"), lambda m: year(m.group(1)) + " "),
    # percentages
    (re.compile(rf"({NUM})\s?(?:%|प्रतिशत|फ़ीसदी|फीसदी)"), lambda m: f"{amount(m.group(1))} प्रतिशत"),
    # ordinals 1st, 2nd, 21वां/21वीं
    (re.compile(r"\b(\d+)(?:st|nd|rd|th)\b"), lambda m: ordinal(m.group(1))),
    (re.compile(r"(\d+)\s?(?:वां|वाँ|वें)"), lambda m: ordinal(m.group(1))),
    (re.compile(r"(\d+)\s?(?:वीं)"), lambda m: ordinal(m.group(1), "f")),
    # units
    (re.compile(rf"({NUM})\s?({'|'.join(sorted(map(re.escape, UNITS), key=len, reverse=True))})(?![\w])", re.I),
     lambda m: f"{amount(m.group(1))} {UNITS[m.group(2).lower()]}"),
    # ranges 10-15 -> दस से पंद्रह
    (re.compile(r"\b(\d+)\s?[-–]\s?(\d+)\b"), lambda m: f"{cardinal(m.group(1))} से {cardinal(m.group(2))}"),
    # plain numbers last
    (re.compile(NUM), lambda m: amount(m.group(0))),
]

def normalize(text):
    """Replace every number expression in ``text`` with Hindi words."""
    text = text.translate(DEVA_DIGITS)
    for pattern, repl in RULES:
        text = pattern.sub(repl, text)
    return re.sub(r"\s+", " ", text).strip()

if __name__ == "__main__":
    for t in ["आज 15 अगस्त 2026 है, और मेरी मीटिंग शाम 4:30 बजे है।", "इस फ़ोन की कीमत ₹12,499 है।",
              "मकान ₹1.5 लाख में बिका, और गाड़ी ₹2 करोड़ की।", "सन 1995 में वह 7.5% ब्याज पर 3.5 किलो सोना लाया।",
              "मेरा नंबर 98765 43210 है।", "ट्रेन 6:45 पर और बस 1:30 बजे।", "उसने 21वीं बार 3rd रैंक पाई, 10-15 मिनट में।",
              "तापमान ४२ °C तक गया, दूरी 120 km थी।", "1,00,000 लोग और 2,50,00,000 रुपये।", "10:07 बजे पहुँचे।"]:
        print(t, "\n  ->", normalize(t))
