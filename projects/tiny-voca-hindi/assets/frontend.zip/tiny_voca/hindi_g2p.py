"""Rule-based Hindi grapheme-to-phoneme conversion for tiny-voca (front end "hindi").

Pipeline per word: Devanagari -> akshara units (consonant + vowel sign / virama /
nasal marks) -> phones with every inherent schwa written out -> schwa deletion ->
anusvara resolution -> small allophonic rules. Latin-script words go through a
lexicon of Devanagari spellings (filled offline, see hinglish lexicon).

Schwa deletion (after Ohala 1983 / Narasimhan et al. 2004): the word-final schwa
goes, then medial schwas are scanned right to left and deleted in the context
V C _ C V, never two in a row. Known limit: compounds and some suffixed forms
(morpheme boundaries) are not visible to the rule; EXCEPTIONS fixes the frequent ones.
"""
import re
import unicodedata

# ---- inventory ---------------------------------------------------------------------------------------
CONS = {
    "क": "k", "ख": "kʰ", "ग": "ɡ", "घ": "ɡʱ", "ङ": "ŋ",
    "च": "tʃ", "छ": "tʃʰ", "ज": "dʒ", "झ": "dʒʱ", "ञ": "ɲ",
    "ट": "ʈ", "ठ": "ʈʰ", "ड": "ɖ", "ढ": "ɖʱ", "ण": "ɳ",
    "त": "t̪", "थ": "t̪ʰ", "द": "d̪", "ध": "d̪ʱ", "न": "n",
    "प": "p", "फ": "pʰ", "ब": "b", "भ": "bʱ", "म": "m",
    "य": "j", "र": "ɾ", "ल": "l", "व": "ʋ",
    "श": "ʃ", "ष": "ʃ", "स": "s", "ह": "ɦ", "ळ": "l",
}
NUKTA_CONS = {"क": "q", "ख": "x", "ग": "ɣ", "ज": "z", "फ": "f", "ड": "ɽ", "ढ": "ɽʱ", "य": "j", "र": "ɾ", "झ": "ʒ", "ल": "l", "न": "n"}
PRECOMPOSED_NUKTA = {"क़": "क", "ख़": "ख", "ग़": "ग", "ज़": "ज", "ड़": "ड", "ढ़": "ढ",
                     "फ़": "फ", "य़": "य", "ऩ": "न", "ऱ": "र", "ऴ": "ळ"}
INDEP_VOWELS = {"अ": "ə", "आ": "aː", "इ": "ɪ", "ई": "iː", "उ": "ʊ", "ऊ": "uː", "ऋ": "ɾɪ", "ए": "eː", "ऐ": "ɛː",
                "ओ": "oː", "औ": "ɔː", "ऑ": "ɔ", "ऍ": "æ", "ऎ": "eː", "ऒ": "oː"}
MATRAS = {"ा": "aː", "ि": "ɪ", "ी": "iː", "ु": "ʊ", "ू": "uː", "ृ": "ɾɪ", "े": "eː", "ै": "ɛː",
          "ो": "oː", "ौ": "ɔː", "ॉ": "ɔ", "ॅ": "æ", "ॆ": "eː", "ॊ": "oː"}
VIRAMA, NUKTA, ANUSVARA, CHANDRABINDU, VISARGA, AVAGRAHA = "्", "़", "ं", "ँ", "ः", "ऽ"

ORAL_VOWELS = ("ə", "aː", "ɪ", "iː", "ʊ", "uː", "eː", "ɛː", "oː", "ɔː", "ɔ", "æ", "ɛ")
NASAL = {"ə": "ə̃", "aː": "ãː", "ɪ": "ɪ̃", "iː": "ĩː", "ʊ": "ʊ̃", "uː": "ũː", "eː": "ẽː", "ɛː": "ɛ̃ː",
         "oː": "õː", "ɔː": "ɔ̃ː", "ɔ": "ɔ̃", "æ": "æ̃", "ɛ": "ɛ̃"}
VOWELS = ORAL_VOWELS + tuple(NASAL.values())
CONSONANTS = ("k", "kʰ", "ɡ", "ɡʱ", "ŋ", "tʃ", "tʃʰ", "dʒ", "dʒʱ", "ɲ", "ʈ", "ʈʰ", "ɖ", "ɖʱ", "ɳ",
              "t̪", "t̪ʰ", "d̪", "d̪ʱ", "n", "p", "pʰ", "b", "bʱ", "m", "j", "ɾ", "l", "ʋ", "ʃ", "s", "ɦ",
              "q", "x", "ɣ", "z", "f", "ɽ", "ɽʱ", "ʒ")
VOICELESS = frozenset(("k", "kʰ", "tʃ", "tʃʰ", "ʈ", "ʈʰ", "t̪", "t̪ʰ", "p", "pʰ", "ʃ", "s", "q", "x", "f"))
VOWEL_SET = frozenset(VOWELS)

# Label of the alignment recogniser (wav2vec2-lv-60-espeak-cv-ft) for every phone, re-estimated from
# the recogniser's own posteriors on pilot audio (estimate_labels.py: align, average posteriors at
# each phone's emission frame, switch to a clearly better label, repeat). It is a coarse multilingual
# recogniser: it merges length, aspiration and retroflexion (aː->a, bʱ->b, ʈ->t). That only affects
# where boundaries go; the TTS inventory keeps every distinction. Pilot token probability 0.36 -> 0.58.
ALIGNER_LABEL = {"aː": "a", "b": "b", "bʱ": "b", "dʒ": "dʒ", "dʒʱ": "dʒ", "d̪": "d", "d̪ʱ": "d", "eː": "i", "f": "f", "iː": "i", "j": "j", "k": "k", "kʰ": "k", "l": "l", "m": "m", "n": "n", "oː": "u", "p": "p", "pʰ": "f", "q": "ɡ", "s": "s", "tʃ": "tʃ", "tʃʰ": "tʃ", "t̪": "t", "t̪ʰ": "t", "uː": "uː", "x": "k", "z": "z", "ãː": "a", "æ": "ɛ", "æ̃": "ɛ̃", "õː": "u", "ĩː": "i", "ŋ": "ŋ", "ũː": "u", "ɔ": "o", "ɔː": "o", "ɔ̃": "ɔ̃", "ɔ̃ː": "ɑ̃", "ɖ": "d", "ɖʱ": "d", "ə": "a", "ə̃": "a", "ɛ": "e", "ɛː": "e", "ɛ̃": "ɛ̃", "ɛ̃ː": "e", "ɡ": "ɡ", "ɡʱ": "ɡ", "ɣ": "ɡ", "ɦ": "h", "ɪ": "i", "ɪ̃": "ɪ", "ɲ": "n", "ɳ": "n", "ɽ": "r", "ɽʱ": "r", "ɾ": "r", "ʃ": "ʃ", "ʈ": "t", "ʈʰ": "t", "ʊ": "u", "ʊ̃": "n", "ʋ": "v", "ʒ": "ʒ", "ẽː": "e"}

# ---- exceptions: whole-word pronunciations the rules get wrong -------------------------------------
EXCEPTIONS = {
    "वह": "ʋoː", "यह": "jɛː", "वे": "ʋeː", "ये": "jeː", "कहाँ": "kəɦãː", "बहुत": "bəɦʊt̪",
    "पहले": "pɛɦleː", "पहला": "pɛɦlaː", "पहली": "pɛɦliː", "कहना": "kɛɦnaː", "रहना": "ɾɛɦnaː",
    "बहन": "bɛɦɛn", "शहर": "ʃɛɦɛɾ", "नहीं": "nəɦĩː", "महीना": "məɦiːnaː", "ज्ञान": "ɡjaːn",
    "और": "ɔːɾ", "ऐसा": "ɛːsaː", "मैं": "mɛ̃ː", "हैं": "ɦɛ̃ː", "है": "ɦɛː",
}

# ---- akshara parsing -------------------------------------------------------------------------------
def _units(word):
    """Yield ('C', phone, vowel|None, protected) or ('V', phone) or ('N', 'anusvara'|'chandra') units."""
    word = unicodedata.normalize("NFC", word)
    word = "".join(PRECOMPOSED_NUKTA.get(c, c) + (NUKTA if c in PRECOMPOSED_NUKTA else "") for c in word)
    units, i = [], 0
    while i < len(word):
        c = word[i]
        if c in CONS:
            nukta = i + 1 < len(word) and word[i+1] == NUKTA
            phone = NUKTA_CONS.get(c, CONS[c]) if nukta else CONS[c]
            i += 2 if nukta else 1
            nxt = word[i] if i < len(word) else ""
            if nxt == VIRAMA:
                units.append(["C", phone, None]); i += 1
            elif nxt in MATRAS:
                units.append(["C", phone, MATRAS[nxt]]); i += 1
            else:
                units.append(["C", phone, "ə"])
        elif c in INDEP_VOWELS:
            units.append(["V", INDEP_VOWELS[c]]); i += 1
        elif c == ANUSVARA:
            units.append(["N", "anusvara"]); i += 1
        elif c == CHANDRABINDU:
            units.append(["N", "chandra"]); i += 1
        elif c == VISARGA:
            units.append(["H"]); i += 1
        else:
            i += 1   # avagraha, zero-width joiners, stray marks
    return units

PLACE = {**{p: "ŋ" for p in ("k", "kʰ", "ɡ", "ɡʱ")}, **{p: "ɲ" for p in ("tʃ", "tʃʰ", "dʒ", "dʒʱ")},
         **{p: "ɳ" for p in ("ʈ", "ʈʰ", "ɖ", "ɖʱ")}, **{p: "n" for p in ("t̪", "t̪ʰ", "d̪", "d̪ʱ", "n")},
         **{p: "m" for p in ("p", "pʰ", "b", "bʱ", "m")}}

def _segments(units):
    """Flat list of [phone, kind, deletable, nasal] where kind is 'C' or 'V'."""
    seg = []
    for u in units:
        if u[0] == "C":
            seg.append([u[1], "C", False, False])
            if u[2] is not None:
                ph = u[2]
                if ph == "ɾɪ":   # ृ after a consonant: r + i
                    seg.append(["ɾ", "C", False, False]); ph = "ɪ"
                seg.append([ph, "V", ph == "ə", False])
        elif u[0] == "V":
            ph = u[1]
            if ph == "ɾɪ":
                seg.append(["ɾ", "C", False, False]); ph = "ɪ"
            seg.append([ph, "V", False, False])   # independent vowels are never deleted
        elif u[0] == "N":
            if seg and seg[-1][1] == "V":
                seg[-1][3] = u[1]; seg[-1][2] = False   # a nasalised schwa is kept
        elif u[0] == "H":
            if u is units[-1]:
                seg.append(["ɦ", "C", False, False])   # final visarga: प्रातः -> ...t̪əɦ; medial (दुःख) is silent
    return seg

def _delete_schwas(seg):
    if len(seg) >= 3 and seg[-1][:2] == ["ə", "V"] and seg[-1][2] and seg[-2][1] == "C":
        # keep the final schwa after a cluster ending in य or र (सत्य, मित्र, चन्द्र)
        cluster_y_r = seg[-3][1] == "C" and seg[-2][0] in ("j", "ɾ", "ʋ")   # सत्य, मित्र, महत्व
        if not cluster_y_r:
            seg.pop()
    elif len(seg) == 2 and seg[-1][2]:
        pass   # one-akshara words (न, व, क) keep their vowel
    i, just_deleted = len(seg) - 2, False
    while i >= 2:
        s = seg[i]
        closed = seg[i-2][3] == "anusvara" and seg[i-1][0] in PLACE   # कंपनी: kəm.pə.niː, the m closes the syllable
        if (s[2] and not just_deleted and not closed and seg[i-1][1] == "C" and seg[i-2][1] == "V"
                and seg[i+1][1] == "C" and i + 2 < len(seg) and seg[i+2][1] == "V"):
            del seg[i]; just_deleted = True; i -= 2
            continue
        just_deleted = False
        i -= 1
    return seg

def _realise(seg):
    out = []
    for k, (ph, kind, _, nasal) in enumerate(seg):
        if kind == "C":
            out.append(ph); continue
        if nasal == "anusvara":
            nxt = seg[k+1][0] if k + 1 < len(seg) and seg[k+1][1] == "C" else None
            # Short vowels (and aː) close with a nasal of the stop's place: संगीत, हिंदी, मुंबई, शांति.
            # Other long vowels just nasalise: चाहेंगे, बातें, सोंठ.
            if nxt in PLACE and ph in ("ə", "ɪ", "ʊ", "aː"):
                out += [ph, PLACE[nxt]]; continue
            out.append(NASAL[ph]); continue
        if nasal == "chandra":
            out.append(NASAL[ph]); continue
        out.append(ph)
    # ə before a coda ɦ (not followed by a vowel) is pronounced ɛ: कहना, रहता, पहचान
    for k in range(len(out) - 1):
        if out[k] == "ə" and out[k+1] == "ɦ" and (k + 2 == len(out) or out[k+2] not in VOWEL_SET):
            out[k] = "ɛ"
    return out

# Second halves of frequent compounds: the stem and the suffix get schwa deletion separately
# (राष्ट्र+पति -> raːʃʈɾəpət̪ɪ, not ...ɾəpt̪ɪ). Only split when the stem has at least two aksharas.
COMPOUND_TAILS = ("पति", "पूर्ण", "पुर", "नगर", "गढ़", "प्रदेश", "मंत्री", "वाद", "वादी", "भवन", "पत्र")

def _rules(word):
    out = _realise(_delete_schwas(_segments(_units(word))))
    if word.endswith("िंग") and out[-2:] == ["ŋ", "ɡ"]:
        out.pop()   # English -ing loans (मीटिंग, शॉपिंग) end in ŋ
    return out

_EXC_CACHE = {}
def word_phones(word):
    """Phones for one Devanagari word (no punctuation)."""
    if word in EXCEPTIONS:
        if word not in _EXC_CACHE:
            _EXC_CACHE[word] = _split_ipa(EXCEPTIONS[word])
        return list(_EXC_CACHE[word])
    for tail in COMPOUND_TAILS:
        stem = word[:-len(tail)]
        if word.endswith(tail) and len([u for u in _units(stem) if u[0] in "CV"]) >= 2:
            return word_phones(stem) + _rules(tail)
    return _rules(word)

_ALL = sorted(set(CONSONANTS) | VOWEL_SET, key=len, reverse=True)
def _split_ipa(s):
    out, i = [], 0
    while i < len(s):
        for p in _ALL:
            if s.startswith(p, i):
                out.append(p); i += len(p); break
        else:
            raise ValueError(f"cannot split {s!r} at {i}")
    return out

LATIN_WORD = re.compile(r"[A-Za-z][A-Za-z']*")
DEVA_WORD = re.compile(r"[ऀ-ॣॱ-ॿ]+")
def words(piece, lexicon=None):
    """A text piece (no punctuation) -> list of words, each a list of (phone, stress=0)."""
    result = []
    for token in piece.split():
        if re.search(r"[A-Za-z]", token):
            # Each Latin word inside the token (so "follow-up" -> follow, up) is looked up on its own,
            # the same split make_manifest used when it checked the lexicon covers the corpus.
            def spell(m):
                spelled = (lexicon or {}).get(m.group(0).lower())
                if spelled is None:
                    raise KeyError(f"no Devanagari spelling for Latin word {m.group(0)!r} in {token!r}")
                return f" {spelled} "
            token = LATIN_WORD.sub(spell, token)
        for w in DEVA_WORD.findall(token):
            phones = word_phones(w)
            if phones:
                result.append([(p, 0) for p in phones])
    return result

if __name__ == "__main__":
    import sys
    for line in sys.argv[1:] or ["कमला ने कमरे में खाना खाया", "समझना समझा समझकर लड़की पढ़ाई धड़कन",
                                  "संगीत हँसना गंगा चंचल ठंडा अंत कंबल संसार", "ज़रूरी फ़ाइल ग़लती ख़त्म क्षत्रिय मित्र सत्य",
                                  "बदलना सरकार बचपन लड़कियाँ कृपया दुःख कहना"]:
        print(line)
        print("  " + " | ".join(" ".join(word_phones(w)) for w in DEVA_WORD.findall(line)))
